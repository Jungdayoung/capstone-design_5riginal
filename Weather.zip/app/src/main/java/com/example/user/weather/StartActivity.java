package com.example.user.weather;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static com.example.user.weather.R.id.button_start;

public class StartActivity extends AppCompatActivity {

    Button btn;
    TextView txt;
    Intent intent; //다음화면으로 넘어가기위해

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        txt = (TextView)findViewById(R.id.textView_start);
        btn = (Button)findViewById(R.id.button_start);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 액티비티 전환
                intent = new Intent(StartActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}

